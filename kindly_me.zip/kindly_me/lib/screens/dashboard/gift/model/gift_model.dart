import 'dart:ffi';

class GiftModel {
  String? recipientName;
  String? recipientPhone;
  Double? amount;
  GiftModel({
    this.amount,
    this.recipientName,
    this.recipientPhone,
});


}