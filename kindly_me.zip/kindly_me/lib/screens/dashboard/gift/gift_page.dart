import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/utils/validator.dart';
import 'package:kindly_me/widgets/my_button.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../dialogs/congrats_dialogue.dart';
import '../../../dialogs/congrats_dialogue1.dart';
import '../../../dialogs/delivered_order_dialogue.dart';
import '../../../resources/resources.dart';

class GiftView extends StatefulWidget {
  const GiftView({Key? key}) : super(key: key);

  @override
  State<GiftView> createState() => _GiftViewState();
}

class _GiftViewState extends State<GiftView> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController nameCT = TextEditingController();
  TextEditingController phoneCT = TextEditingController();
  TextEditingController customAmountCT = TextEditingController();
  String? value;
  int selectedIndex = 0;
  int selectedAmount = 0;
  List<String> amounts = ["05", "10", "15", "20"];

  @override
  void initState() {
    customAmountCT = TextEditingController(text: amounts[0]);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: getPaddingWidget(
        EdgeInsets.only(top: FetchPixels.getPixelHeight(20)),
        Form(
          key: formKey,
          child: Container(
            padding: EdgeInsets.all(FetchPixels.getPixelWidth(30)),
            decoration: BoxDecoration(
                color: R.colors.whiteColor,
                borderRadius: BorderRadius.circular(4)),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                "How would you like to send it?",
                style: R.textStyle.mediumPoppins().copyWith(
                      fontSize: 16,
                    ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Column(
                children: List.generate(2, (index) {
                  return Padding(
                    padding: EdgeInsets.symmetric(
                        vertical: FetchPixels.getPixelHeight(5)),
                    child: selectMethod(index),
                  );
                }),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Text(
                "Who is it for?",
                style: R.textStyle.mediumPoppins().copyWith(
                      fontSize: 16,
                    ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              TextFormField(
                autovalidateMode: AutovalidateMode.onUserInteraction,
                controller: nameCT,
                cursorColor: R.colors.theme,
                textInputAction: TextInputAction.next,
                keyboardType: TextInputType.name,
                validator: (value) => FieldValidator.validateName(value!),
                decoration: R.decorations
                    .textFormFieldDecoration(null, "Recipient Name"),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              TextFormField(
                autovalidateMode: AutovalidateMode.onUserInteraction,
                controller: phoneCT,
                cursorColor: R.colors.theme,
                textInputAction: TextInputAction.done,
                keyboardType: TextInputType.number,
                validator: (value) =>
                    FieldValidator.validatePhoneNumber(value!),
                decoration: R.decorations
                    .textFormFieldDecoration(null, "Recipient Number"),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Text(
                "Choose Amount",
                style: R.textStyle.mediumPoppins().copyWith(
                      fontSize: 16,
                    ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(4, (index) {
                  return amount(index);
                }),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              TextFormField(
                autovalidateMode: AutovalidateMode.onUserInteraction,
                cursorColor: R.colors.theme,
                controller: customAmountCT,
                decoration: R.decorations
                    .textFormFieldDecoration(null, "Custom amount")
                    .copyWith(
                      prefixIcon: Padding(
                        padding: const EdgeInsets.only(right: 5),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(topLeft: Radius.circular(4),bottomLeft: Radius.circular(4)),
                              color: R.colors.theme),
                          height: FetchPixels.getPixelHeight(30),
                          width: FetchPixels.getPixelWidth(30),
                          child: Center(
                            child: Text(
                              "\$",
                              style: R.textStyle.mediumPoppins().copyWith(
                                  fontSize: 16, color: R.colors.whiteColor),
                            ),
                          ),
                        ),
                      ),
                    ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              MyButton(
                  onTap: () {
                    if (formKey.currentState!.validate()) {
                      Get.dialog(OrderStatusDialog(
                        onTap: () {
                          Get.back();
                          Get.dialog(CongratsDialogue1(
                              text: "Your Gift Has Been Sent!",
                              image: R.images.giftImage));
                        },
                        image: R.images.giftImage,
                        text: "Are You Sure You want to Send Gift",
                      ));
                    }
                  },
                  buttonText: "Send Gift"),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Text(
                R.dummyData.shortText,
                style: R.textStyle.regularPoppins().copyWith(
                      fontSize: 14,
                    ),
              ),
              Text(
                "Terms & Conditions",
                style: R.textStyle
                    .regularPoppins()
                    .copyWith(fontSize: 14, color: R.colors.theme),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget selectMethod(index) {
    return InkWell(
      onTap: () {
        selectedIndex = index;
        setState(() {});
      },
      child: Container(
        padding:
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(10)),
        height: FetchPixels.getPixelHeight(50),
        width: FetchPixels.width,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
                width: FetchPixels.getPixelWidth(1),
                color: selectedIndex == index
                    ? R.colors.theme
                    : R.colors.hintText)),
        child: Row(children: [
          Container(
            height: FetchPixels.getPixelHeight(22),
            width: FetchPixels.getPixelWidth(22),
            decoration: BoxDecoration(
                border: Border.all(
                    width: FetchPixels.getPixelWidth(
                        selectedIndex == index ? 5 : 1),
                    color: selectedIndex == index
                        ? R.colors.theme
                        : R.colors.hintText),
                color: R.colors.whiteColor,
                shape: BoxShape.circle),
          ),
          getHorSpace(FetchPixels.getPixelWidth(10)),
          Text(
            index == 0 ? "Text" : "Email",
            style: R.textStyle
                .mediumPoppins()
                .copyWith(fontSize: 14, color: R.colors.theme),
          ),
          Spacer(),
          getAssetImage(
            index == 0 ? R.images.textImage : R.images.emailImage,
            height: FetchPixels.getPixelHeight(25),
            width: FetchPixels.getPixelWidth(25),
          )
        ]),
      ),
    );
  }

  Widget amount(index) {
    return InkWell(
      onTap: () {
        selectedAmount = index;
        print(amounts[index]);
        // amounts.indexOf(value!,);
        setState(() {
          customAmountCT = TextEditingController(text: amounts[index]);
        });
      },
      child: Container(
        padding:
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(10)),
        height: FetchPixels.getPixelHeight(50),
        width: FetchPixels.getPixelWidth(65),
        decoration: BoxDecoration(
            color:
                selectedAmount == index ? R.colors.theme : R.colors.whiteColor,
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
                width: FetchPixels.getPixelWidth(1.5), color: R.colors.theme)),
        child: Center(
          child: Text(
            "\$ ${amounts[index]}",
            style: R.textStyle.mediumPoppins().copyWith(
                fontSize: 13,
                color: selectedAmount == index
                    ? R.colors.whiteColor
                    : R.colors.theme),
          ),
        ),
      ),
    );
  }
}
