import 'package:flutter/material.dart';
import 'package:kindly_me/screens/dashboard/profile/profile_page.dart';
import 'package:provider/provider.dart';

import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../resources/resources.dart';
import '../auth/provider/auth_provider.dart';
import 'gift/gift_page.dart';
import 'home/home_page.dart';
import 'notifications/notifications_page.dart';

class DashboardView extends StatefulWidget {
  final index;
  const DashboardView({Key? key, this.index}) : super(key: key);

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {
  PageController pageController = PageController();

  @override
  void initState() {
    setState(() {
      currentPage = widget.index;
      pageController = PageController(initialPage: currentPage);
    });
    super.initState();
  }

  int currentPage = 0;

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, child) {
        return Scaffold(
          backgroundColor: R.colors.bgColor,
          appBar: AppBar(
            iconTheme: IconThemeData(
              color: R.colors.whiteColor, //change your color here
            ),
            automaticallyImplyLeading: false,
            backgroundColor: Colors.white,
            elevation: 0.0,
            centerTitle: true,
            title:currentPage==3?getAssetImage(R.images.logo,height: FetchPixels.getPixelHeight(35),
            width: FetchPixels.getPixelWidth(170)
            ): Text(
                currentPage == 0
                    ? "Home"
                    : currentPage == 1
                        ? "Gifts"
                        : currentPage == 2
                            ? "Notifications"
                            : "",
                style: R.textStyle.mediumPoppins()),
          ),
          body: getPaddingWidget(
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
            PageView(
                controller: pageController,
                physics: const NeverScrollableScrollPhysics(),
                onPageChanged: (page) {
                  print("on page changed $page");
                  currentPage = page;
                  // setState(() {});
                },
                children: [
                  HomeView(),
                  GiftView(),
                  NotificationsView(),
                  ProfileView(),
                ]),
          ),
          bottomNavigationBar: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                height: FetchPixels.getPixelHeight(80),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    color: R.colors.whiteColor,
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 2,
                        color: R.colors.theme.withOpacity(0.2),
                        // spreadRadius: 0.5,
                      )
                    ],
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(15),
                        topRight: Radius.circular(15))),
                child: Padding(
                  padding: EdgeInsets.all(2),
                  child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        tab(authProvider, 0, R.images.selectedHome,
                            R.images.home, "Home"),
                        tab(authProvider, 1, R.images.selectedGift,
                            R.images.dashGift, "Gift"),
                        tab(authProvider, 2, R.images.selectedNoti,
                            R.images.noti, "Notifications"),
                        tab(authProvider, 3, R.images.selectedProfile,
                            R.images.dashProfile, "Profile"),
                      ]),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget tab(
    AuthProvider authProvider,
    int index,
    String image,
    String image2,
    String text,
  ) {
    return InkWell(
      onTap: () {
        print("index $currentPage");
        pageController.jumpToPage(index);
        authProvider.update();
        // setState(() {});
        print('current page$currentPage');
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: FetchPixels.getPixelHeight(30),
            width: FetchPixels.getPixelWidth(30),
            child: getAssetImage(
              currentPage == index ? image : image2,
              // color: currentPage == index ? R.colors.theme : R.colors.hintText,
            ),
          ),
          Text(
            text,
            style: R.textStyle
                .mediumPoppins()
                .copyWith(fontSize: 13, color: R.colors.theme),
          )
        ],
      ),
    );
  }
}
