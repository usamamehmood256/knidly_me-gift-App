
import 'package:flutter/material.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';


class NotificationWidget extends StatelessWidget {
  const NotificationWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(4),

          color: R.colors.whiteColor),
      child: ListTile(
        leading: SizedBox(
          height: FetchPixels.getPixelHeight(45),

          width: FetchPixels.getPixelWidth(35),
          child: getAssetImage(R.images.gift),),
        title: Text("You Sent a Gift",style: R.textStyle.mediumPoppins().copyWith(color: R.colors.theme,fontSize: 14),),
        subtitle: Text("Gift sent to Kevin for the amount of \$5.",style: R.textStyle.regularPoppins().copyWith(fontSize: 12,color: R.colors.hintText),),
      ),
    );
  }
}
