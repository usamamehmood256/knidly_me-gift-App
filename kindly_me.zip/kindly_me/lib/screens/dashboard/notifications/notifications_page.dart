import 'package:flutter/material.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';

import 'notification_widget.dart';

class NotificationsView extends StatelessWidget {
  const NotificationsView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(itemBuilder: (context, index) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: FetchPixels.getPixelHeight(7)),
        child: NotificationWidget(),
      );
    },);
  }
}
