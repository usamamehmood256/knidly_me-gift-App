import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/base/widget_utils.dart';
import 'package:kindly_me/screens/dashboard/dashboard_page.dart';

import '../../../resources/resources.dart';

class HomeView extends StatefulWidget {
  HomeView({Key? key}) : super(key: key);

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  List<String> name = ["Choose a Person", "Select Amount", "Send Gift"];

  List<String> images = [R.images.choose, R.images.amount, R.images.gift];

  PageController imagePC = PageController(
    viewportFraction: 0.8,
    initialPage: 0,
  );
  int currentPage = 0;
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          getVerSpace(FetchPixels.getPixelHeight(20)),
          Container(
            height: FetchPixels.getPixelHeight(270),
            width: FetchPixels.width,
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [R.colors.theme, R.colors.gradient],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight),
                borderRadius: BorderRadius.circular(7)),
            child: getPaddingWidget(
              EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
              Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Make\nSomeone\nSmile Today",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 30, color: R.colors.whiteColor),
                    ),
                    InkWell(
                      onTap: (){
                        Get.offAll(const DashboardView(index: 1,));
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: FetchPixels.getPixelWidth(20),
                            vertical: FetchPixels.getPixelHeight(12)),
                        decoration: BoxDecoration(
                            color: R.colors.whiteColor,
                            borderRadius: BorderRadius.circular(20)),
                        child: Text(
                          "Send a Gift",
                          style:
                              R.textStyle.mediumPoppins().copyWith(fontSize: 13),
                        ),
                      ),
                    ),
                  ]),
            ),
          ),
          getVerSpace(FetchPixels.getPixelHeight(15)),
          Container(
            padding:
                EdgeInsets.symmetric(vertical: FetchPixels.getPixelHeight(10)),
            width: FetchPixels.width,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: R.colors.whiteColor),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(3, (index) {
                  return guideWidget(index);
                })),
          ),
          getVerSpace(FetchPixels.getPixelHeight(15)),
          Container(
            height: FetchPixels.getPixelHeight(270),
            width: FetchPixels.width,
            color: R.colors.whiteColor,
            child: PageView.builder(
              controller: imagePC,
              onPageChanged: (page) {
                currentPage = page;
                setState(() {});
              },
              itemBuilder: (context, index) {
                return Padding(
                  padding:  EdgeInsets.all(FetchPixels.getPixelHeight(5)),
                  child: Container(
                    height: FetchPixels.getPixelHeight(300),
                    width: FetchPixels.width,
                    decoration: BoxDecoration(
                        image: getDecorationAssetImage(context, R.images.proImage,
                            fit: BoxFit.cover)),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget guideWidget(index) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(15),
          decoration:
              BoxDecoration(color: R.colors.bgColor, shape: BoxShape.circle),
          child: getAssetImage(images[index],
              height: FetchPixels.getPixelHeight(25),
              width: FetchPixels.getPixelWidth(25)),
        ),
        Text(
          name[index],
          style: R.textStyle
              .mediumPoppins()
              .copyWith(fontSize: 9, color: R.colors.hintText),
        )
      ],
    );
  }
}
