import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';

import '../../../dialogs/delivered_order_dialogue.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';

class MainSettingsView extends StatefulWidget {
  const MainSettingsView({Key? key}) : super(key: key);

  @override
  State<MainSettingsView> createState() => _MainSettingsViewState();
}

class _MainSettingsViewState extends State<MainSettingsView> {
  bool availStatus = false;
  bool notification = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: R.colors.bgColor,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(
          color: R.colors.theme, // <-- SEE HERE
        ),
        backgroundColor: R.colors.whiteColor,
        title: Text(
          "Settings",
          style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),
        ),
      ),
      body: getPaddingWidget(
        EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        SingleChildScrollView(
          child: Column(children: [
            getVerSpace(FetchPixels.getPixelHeight(10)),
            Container(
              padding: EdgeInsets.symmetric(
                  horizontal: FetchPixels.getPixelWidth(10)),
              height: FetchPixels.getPixelHeight(120),
              width: FetchPixels.width,
              decoration: BoxDecoration(
                  color: R.colors.whiteColor,
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  getVerSpace(FetchPixels.getPixelHeight(5)),
                  Text(
                    "Settings",
                    style: R.textStyle
                        .mediumPoppins()
                        .copyWith(fontSize: 15, color: R.colors.hintText),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Availability Status",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(fontSize: 15, color: R.colors.theme),
                      ),
                      FlutterSwitch(
                        padding: FetchPixels.getPixelHeight(2),
                        height: FetchPixels.getPixelHeight(25),
                        width: FetchPixels.getPixelWidth(50),
                        activeColor: R.colors.theme,
                        value: (availStatus),
                        onToggle: (value) {
                          setState(() {
                            availStatus = !availStatus;
                          });
                        },
                      ),
                    ],
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Send me Notifications",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(fontSize: 15, color: R.colors.theme),
                      ),
                      FlutterSwitch(
                        padding: FetchPixels.getPixelHeight(2),
                        height: FetchPixels.getPixelHeight(25),
                        width: FetchPixels.getPixelWidth(50),
                        activeColor: R.colors.theme,
                        value: (notification),
                        onToggle: (bool value) {
                          setState(() {
                            notification = !notification;
                          });
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
            getVerSpace(FetchPixels.getPixelHeight(10)),
            Container(
              padding: EdgeInsets.symmetric(
                  horizontal: FetchPixels.getPixelWidth(10)),
              height: FetchPixels.getPixelHeight(90),
              width: FetchPixels.width,
              decoration: BoxDecoration(
                  color: R.colors.whiteColor,
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Account",
                    style: R.textStyle
                        .mediumPoppins()
                        .copyWith(fontSize: 15, color: R.colors.hintText),
                  ),
                  InkWell(
                    onTap: () {
                      Get.toNamed(Routes.changeCurrentPass);
                    },
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 15,
                          child: getAssetImage(R.images.lock,
                              height: FetchPixels.getPixelHeight(20),
                              width: FetchPixels.getPixelWidth(20)),
                        ),
                        getHorSpace(FetchPixels.getPixelWidth(20)),
                        Text(
                          "Change Password",
                          style: R.textStyle
                              .mediumPoppins()
                              .copyWith(fontSize: 15, color: R.colors.theme),
                        ),
                        Spacer(),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: FetchPixels.getPixelHeight(20),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            getVerSpace(FetchPixels.getPixelHeight(10)),
            Container(
              padding: EdgeInsets.symmetric(
                  horizontal: FetchPixels.getPixelWidth(10)),
              height: FetchPixels.getPixelHeight(80),
              width: FetchPixels.width,
              decoration: BoxDecoration(
                  color: R.colors.whiteColor,
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Register & Logout",
                    style: R.textStyle
                        .mediumPoppins()
                        .copyWith(fontSize: 15, color: R.colors.hintText),
                  ),
                  InkWell(
                    onTap: () {
                      Get.dialog(OrderStatusDialog(
                        onTap: () {
                          Get.offAllNamed(Routes.loginView);
                        },
                        text: "Are You Sure You Want To LOGOUT!",
                        image: R.images.logoutImage,
                      ));
                    },
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: R.colors.theme,
                          radius: 15,
                          child: getAssetImage(R.images.logout,
                              height: FetchPixels.getPixelHeight(18),
                              width: FetchPixels.getPixelWidth(18)),
                        ),
                        getHorSpace(FetchPixels.getPixelWidth(20)),
                        Text(
                          "LOGOUT",
                          style: R.textStyle
                              .mediumPoppins()
                              .copyWith(fontSize: 15, color: R.colors.theme),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
