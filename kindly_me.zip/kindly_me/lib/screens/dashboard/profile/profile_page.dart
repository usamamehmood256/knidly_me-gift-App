import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/base/widget_utils.dart';
import 'package:provider/provider.dart';

import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../auth/provider/auth_provider.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(builder: (context, auth, child) {
      
    
    return SingleChildScrollView(
      child: Column(children: [
        getVerSpace(FetchPixels.getPixelHeight(20)),
        SizedBox(

          height: FetchPixels.getPixelHeight(200),
          width: FetchPixels.width,
          child: Stack(children: [
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: FetchPixels.getPixelHeight(150),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  gradient: LinearGradient(
                      colors: [R.colors.theme, R.colors.gradient],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight),
                ),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      getVerSpace(FetchPixels.getPixelHeight(20)),
                      Text(
                        "Jess Sanchez",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(fontSize: 18, color: R.colors.whiteColor),
                      ),
                      Text(
                        "@jesssanchez",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(fontSize: 15, color: R.colors.whiteColor),
                      ),
                    ]),
              ),
            ),
            Align(
              alignment: Alignment.topCenter,
              child: CircularProfileAvatar(
                "",
                radius: FetchPixels.getPixelHeight(50),
                child:auth.pickedImage==null? getAssetImage(R.images.proImage, boxFit: BoxFit.cover):Image.file(auth.pickedImage!,fit: BoxFit.cover,),
              ),
            )
          ]),
        ),
        getVerSpace(FetchPixels.getPixelHeight(20)),
        Container(
          height: FetchPixels.getPixelHeight(90),
          width: FetchPixels.width,
          decoration: BoxDecoration(
              color: R.colors.whiteColor,
              borderRadius: BorderRadius.circular(4)),
          child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "17",
                      style: R.textStyle
                          .mediumPoppins()
                          .copyWith(fontSize: 19, color: R.colors.theme),
                    ),
                    Text(
                      "Gifts Sent",
                      style:
                          R.textStyle.regularPoppins().copyWith(fontSize: 14),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "18+",
                      style: R.textStyle
                          .mediumPoppins()
                          .copyWith(fontSize: 19, color: R.colors.theme),
                    ),
                    Text(
                      "Kindness Level",
                      style:
                          R.textStyle.regularPoppins().copyWith(fontSize: 14),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "125",
                      style: R.textStyle
                          .mediumPoppins()
                          .copyWith(fontSize: 19, color: R.colors.theme),
                    ),
                    Text(
                      "Contacts",
                      style:
                          R.textStyle.regularPoppins().copyWith(fontSize: 14),
                    ),
                  ],
                ),
              ]),
        ),
        getVerSpace(FetchPixels.getPixelHeight(20)),
        Container(
          padding:
              EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
          height: FetchPixels.getPixelHeight(150),
          width: FetchPixels.width,
          decoration: BoxDecoration(
              color: R.colors.whiteColor,
              borderRadius: BorderRadius.circular(4)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Account Settings",
                style: R.textStyle
                    .mediumPoppins()
                    .copyWith(fontSize: 15, color: R.colors.hintText),
              ),
              InkWell(
                onTap: () {
                  Get.toNamed(Routes.editProfileView);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.profile,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "Edit Profile",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  Get.toNamed(Routes.mainSettingsView);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.settings,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "Main Settings",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        getVerSpace(FetchPixels.getPixelHeight(20)),
        Container(
          padding:
              EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
          height: FetchPixels.getPixelHeight(350),
          width: FetchPixels.width,
          decoration: BoxDecoration(
              color: R.colors.whiteColor,
              borderRadius: BorderRadius.circular(4)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Support",
                style: R.textStyle
                    .mediumPoppins()
                    .copyWith(fontSize: 15, color: R.colors.hintText),
              ),
              InkWell(
                onTap: () {
                  Get.toNamed(Routes.kindlyMeWorksView);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.heart,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "How KindlyMe Works",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  Get.toNamed(Routes.privacyPolicy);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.privacy,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "Privacy Policy",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  Get.toNamed(Routes.termsConditionView);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.terms,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "Terms & Conditions",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  Get.toNamed(Routes.contactUsView);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.contact,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "Contact Us",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
              InkWell(
                onTap: (){
                  Get.toNamed(Routes.faqsView);
                },
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: FetchPixels.getPixelHeight(20),
                      backgroundColor: R.colors.profileFill,
                      child: getAssetImage(R.images.help,
                          height: FetchPixels.getPixelHeight(20),
                          width: FetchPixels.getPixelWidth(20)),
                    ),
                    getHorSpace(FetchPixels.getPixelWidth(10)),
                    Text(
                      "Help / FAQs",
                      style: R.textStyle
                          .regularPoppins()
                          .copyWith(fontSize: 15, color: R.colors.theme),
                    ),
                    const Spacer(),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      size: FetchPixels.getPixelHeight(20),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
        getVerSpace(FetchPixels.getPixelHeight(20)),
      ]),
    );},);
  }
}
