import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/base/widget_utils.dart';

import '../../../resources/resources.dart';

class KindlyMeWorksView extends StatelessWidget {
  const KindlyMeWorksView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: R.colors.bgColor,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(
          color: R.colors.theme, // <-- SEE HERE
        ),
        backgroundColor: R.colors.whiteColor,
        title: Text("About App",style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),),),
      body: SingleChildScrollView(
        child: getPaddingWidget(
          EdgeInsets.all(FetchPixels.getPixelWidth(20)),
          Container(
            padding:   EdgeInsets.all( FetchPixels.getPixelWidth(20)),
            decoration: BoxDecoration(
                color: R.colors.whiteColor,
                borderRadius: BorderRadius.circular(4)),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              getVerSpace(FetchPixels.getPixelHeight(20)),
              Container(
                height: FetchPixels.getPixelHeight(200),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  gradient: LinearGradient(
                      colors: [R.colors.theme, R.colors.gradient],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight),
                ),
              ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
              Text("Why do we User it?",style: R.textStyle.mediumPoppins().copyWith(fontSize: 16,color: R.colors.theme),),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
              Text(R.dummyData.longText,style: R.textStyle.regularPoppins().copyWith(fontSize: 14,color: R.colors.hintText),),
               getVerSpace( FetchPixels.getPixelHeight(20),),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                    Column(children: [
                      Container(
                        height: FetchPixels.getPixelHeight(125),
                        width: FetchPixels.getPixelWidth(150),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          gradient: LinearGradient(
                              colors: [R.colors.theme, R.colors.gradient],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight),
                        ),
                      ),
                      getVerSpace(FetchPixels.getPixelHeight(10)),
                      Container(
                        height: FetchPixels.getPixelHeight(300),
                        width: FetchPixels.getPixelWidth(150),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          gradient: LinearGradient(
                              colors: [R.colors.theme, R.colors.gradient],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight),
                        ),
                      ),
                    ],),
                      Column(children: [
                        Container(
                          height: FetchPixels.getPixelHeight(300),
                          width: FetchPixels.getPixelWidth(150),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            gradient: LinearGradient(
                                colors: [R.colors.theme, R.colors.gradient],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight),
                          ),
                        ),
                        getVerSpace(FetchPixels.getPixelHeight(10)),
                        Container(
                          height: FetchPixels.getPixelHeight(125),
                          width: FetchPixels.getPixelWidth(150),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            gradient: LinearGradient(
                                colors: [R.colors.theme, R.colors.gradient],
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight),
                          ),
                        ),
                      ],),
                  ],)
            ]),
          ),
        ),
      ),
    );
  }
}
