import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/screens/dashboard/dashboard_page.dart';
import 'package:kindly_me/widgets/my_button.dart';
import 'package:provider/provider.dart';

import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
import '../../../routes/app_routes.dart';
import '../../auth/provider/auth_provider.dart';

class EditProfileView extends StatelessWidget {
   EditProfileView({Key? key}) : super(key: key);
TextEditingController emailCT = TextEditingController(text: "usamamehmood256@gmail.com");
TextEditingController userNameCT = TextEditingController(text: "usamamehmood256");
  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(builder: (context, auth, child) {


    return Scaffold(
      backgroundColor: R.colors.bgColor,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(
          color: R.colors.theme, // <-- SEE HERE
        ),
        backgroundColor: R.colors.whiteColor,
        title: Text(
          "Edit Profile",
          style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),
        ),
      ),
      body: getPaddingWidget(
        EdgeInsets.all(FetchPixels.getPixelWidth(20)),
        SingleChildScrollView(
          child: Container(
            padding:   EdgeInsets.all( FetchPixels.getPixelWidth(20)),
            decoration: BoxDecoration(
                color: R.colors.whiteColor,
                borderRadius: BorderRadius.circular(4)),
            child: Column(
                children: [
              getVerSpace(FetchPixels.getPixelHeight(40)),
              SizedBox(
                height: FetchPixels.getPixelHeight(100),
                width: FetchPixels.getPixelWidth(100),
                child: Stack(

                  children: [
                    Align(
                      alignment: Alignment.center,
                      child: InkWell(onTap: (){
                        auth.getImage1();
                        auth.update();
                      },
                        child:auth.pickedImage==null? CircularProfileAvatar(
                          "",
                          radius: FetchPixels.getPixelHeight(60),
                          child:
                              getAssetImage(R.images.proImage, boxFit: BoxFit.cover)
                        ):CircularProfileAvatar(
                  "",
                  radius: FetchPixels.getPixelHeight(60),
                  child: Image.file(auth.pickedImage!,fit: BoxFit.cover, ),
              ),
                      ),
                    ),
                    Align(alignment: Alignment.bottomRight,
                      child: Container(
                        padding: EdgeInsets.all(FetchPixels.getPixelHeight(3)),
                        decoration: BoxDecoration(
                            color: R.colors.theme, shape: BoxShape.circle),
                        child: Icon(Icons.edit,size: FetchPixels.getPixelWidth(20),),
                      ),
                    )
                  ],
                ),
              ),
                  getVerSpace(FetchPixels.getPixelHeight(5)),
              Text("Edit Image",style: R.textStyle.regularPoppins().copyWith(fontSize: 12,color: R.colors.hintText),),
              getVerSpace(FetchPixels.getPixelHeight(40)),
              Align(alignment: Alignment.centerLeft,
                  child: Text("Email",style: R.textStyle.regularPoppins().copyWith(fontSize: 14,color: R.colors.hintText),)),
                  getVerSpace(FetchPixels.getPixelHeight(5)),
              TextFormField(
                cursorColor: R.colors.theme,
                keyboardType: TextInputType.emailAddress,
                textInputAction: TextInputAction.next,

                controller: emailCT,
                decoration: R.decorations.textFormFieldDecoration(null, "email"),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
                  Align(alignment: Alignment.centerLeft,
                      child: Text("Username",style: R.textStyle.regularPoppins().copyWith(fontSize: 14,color: R.colors.hintText),)),
                  getVerSpace(FetchPixels.getPixelHeight(5)),
              TextFormField(
                controller: userNameCT,
                cursorColor: R.colors.theme,
                keyboardType: TextInputType.name,
                textInputAction: TextInputAction.done,
                decoration:
                    R.decorations.textFormFieldDecoration(null, "username"),
              ),
              getVerSpace(FetchPixels.getPixelHeight(40)),
              MyButton(onTap: () {
                Get.snackbar(
                    backgroundColor: R.colors.theme,
                    // duration: Duration(milliseconds: 2000),
                    colorText: R.colors.whiteColor,"Congratulations!", "Your Profile is Up To Date");
                Get.offAll(DashboardView(index: 3,));


              }, buttonText: "Update")
            ]),
          ),
        ),
      ),
    );
    },);
  }
}
