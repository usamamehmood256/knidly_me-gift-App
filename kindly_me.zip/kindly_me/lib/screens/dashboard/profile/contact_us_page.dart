import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/base/widget_utils.dart';
import 'package:kindly_me/utils/validator.dart';
import 'package:kindly_me/widgets/my_button.dart';

import '../../../dialogs/congrats_dialogue.dart';
import '../../../dialogs/congrats_dialogue1.dart';
import '../../../resources/resources.dart';

class ContactUsView extends StatelessWidget {
  ContactUsView({Key? key}) : super(key: key);
  TextEditingController queryCT = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: R.colors.bgColor,
      appBar: AppBar(
        backgroundColor: R.colors.whiteColor,
        centerTitle: true,
        iconTheme: IconThemeData(
          color: R.colors.theme, // <-- SEE HERE
        ),
        title: Text(
          "Contact Us",
          style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),
        ),
      ),
      body: getPaddingWidget(
        EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(25)),
        SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(children: [
              getVerSpace(FetchPixels.getPixelHeight(20)),
              Container(
                padding: EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(10)),
                height: FetchPixels.getPixelHeight(60),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    color: R.colors.whiteColor,
                    borderRadius: BorderRadius.circular(4)),
                child: Align(alignment: Alignment.centerLeft,
                  child: Text(
                    "usamamehmood256@gmail.com",
                    style: R.textStyle
                    .mediumPoppins()
                    .copyWith(fontSize: 13, color: R.colors.hintText),
                  ),
                ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              TextFormField(
                cursorColor: R.colors.theme,
                controller: queryCT,
                validator: (value) => FieldValidator.checkEmpty(value!),
                keyboardType: TextInputType.text,
                maxLines: 5,
                decoration: R.decorations
                    .textFormFieldDecoration(null, "write here...").copyWith(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: const BorderRadius.all(Radius.circular(4)),
                    borderSide: BorderSide(width: 1, color: R.colors.transparent),
                  ),
                )

                    .copyWith(fillColor: R.colors.whiteColor, filled: true),
              ),
              getVerSpace(FetchPixels.getPixelHeight(40)),
              MyButton(
                  onTap: () {
                    if (formKey.currentState!.validate()) {
                      Get.dialog(CongratsDialogue1(
                        text: "Your Query is Submitted Succesfully",
                        image: R.images.logo,
                      ));
                    }
                  },
                  buttonText: "Submit Query")
            ]),
          ),
        ),
      ),
    );
  }
}
