import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/base/widget_utils.dart';

import '../../../../../resources/resources.dart';
import '../../../widgets/app_dropdown.dart';

class FaqsView extends StatefulWidget {
  const FaqsView({Key? key}) : super(key: key);

  @override
  State<FaqsView> createState() => _FaqsViewState();
}

class _FaqsViewState extends State<FaqsView> {
  ExpandableController tipExpandable = ExpandableController();
  TextEditingController tipTC =
      TextEditingController(text: 'Id sed lorem dui vestibulum sagittis.');
  List<String> tips = [R.dummyData.shortText];
  ExpandableController secondExpandable = ExpandableController();
  TextEditingController secondTC =
      TextEditingController(text: 'Id sed lorem dui vestibulum sagittis.');
  List<String> second = [R.dummyData.longerText];
  ExpandableController thirdExpandable = ExpandableController();
  TextEditingController thirdTC =
      TextEditingController(text: 'Id sed lorem dui vestibulum sagittis.');
  List<String> third = [R.dummyData.longText];
  ExpandableController forthExpandable = ExpandableController();
  TextEditingController forthTC =
      TextEditingController(text: 'Id sed lorem dui vestibulum sagittis.');
  List<String> forth = [R.dummyData.shortText];
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: R.colors.bgColor,
      appBar: AppBar(
        centerTitle: true,
        iconTheme: IconThemeData(
          color: R.colors.theme, // <-- SEE HERE
        ),
        backgroundColor: R.colors.whiteColor,
        title: Text(
          "Help/FAQs",
          style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView(children: [
          getVerSpace(FetchPixels.getPixelHeight(10)),
          DropDownDynamicWidget(
            heading: "",
            selectedWord: tipTC.text,
            dropDownItems: tips,
            controller: tipExpandable,
            onSelect: (value) {
              print(value);
              tipTC.text = value;
              print(value);
              setState(() {});
            },
            onTap: () {
              setState(() {});
              tipExpandable.toggle();
            },
          ),
          DropDownDynamicWidget(
            heading: "",
            selectedWord: secondTC.text,
            dropDownItems: second,
            controller: secondExpandable,
            onSelect: (value) {
              print(value);
              secondTC.text = value;
              print(value);
              setState(() {});
            },
            onTap: () {
              setState(() {});
              secondExpandable.toggle();
            },
          ),
          DropDownDynamicWidget(
            heading: "",
            selectedWord: thirdTC.text,
            dropDownItems: third,
            controller: thirdExpandable,
            onSelect: (value) {
              print(value);
              thirdTC.text = value;
              print(value);
              setState(() {});
            },
            onTap: () {
              setState(() {});
              thirdExpandable.toggle();
            },
          ),
          DropDownDynamicWidget(
            heading: "",
            selectedWord: forthTC.text,
            dropDownItems: forth,
            controller: forthExpandable,
            onSelect: (value) {
              print(value);
              forthTC.text = value;
              print(value);
              setState(() {});
            },
            onTap: () {
              setState(() {});
              forthExpandable.toggle();
            },
          ),
        ]),
      ),
    );
  }
}
