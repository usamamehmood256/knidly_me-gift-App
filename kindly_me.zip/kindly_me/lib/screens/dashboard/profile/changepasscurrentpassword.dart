import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';

import '../../../../../../../../resources/resources.dart';
import '../../../../../../../../utils/validator.dart';
import '../../../../widgets/my_button.dart';
import '../../../base/widget_utils.dart';
import '../../../dialogs/congrats_dialogue.dart';

class ChangeCurrentPass extends StatefulWidget {
  const ChangeCurrentPass({Key? key}) : super(key: key);

  @override
  State<ChangeCurrentPass> createState() => _ChangeCurrentPassState();
}

class _ChangeCurrentPassState extends State<ChangeCurrentPass> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  TextEditingController oldPasswordController = TextEditingController();
  FocusNode oldPassFN = FocusNode();
  TextEditingController newPasswordController = TextEditingController();
  FocusNode newPassFN = FocusNode();
  TextEditingController confirmPasswordController = TextEditingController();
  FocusNode conFirmPassFN = FocusNode();
  bool oldPassVisible = false;
  bool newPassVisible = false;
  bool confirmPassVisible = false;
  @override
  void dispose() {
    // TODO: implement dispose
    newPassFN.dispose();
    newPasswordController.dispose();
    oldPassFN.dispose();
    oldPasswordController.dispose();
    conFirmPassFN.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: R.colors.whiteColor,
        centerTitle: true,
        iconTheme: IconThemeData(
          color: R.colors.theme, // <-- SEE HERE
        ),
        title: Text(
          "ChangePassword",
          style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),
        ),
      ),
      backgroundColor: R.colors.bgColor,
      body: SingleChildScrollView(
        child: Form(
          key: formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: getPaddingWidget(
             EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
            Container(

              padding:   EdgeInsets.all( FetchPixels.getPixelWidth(20)),
              decoration: BoxDecoration(
                  color: R.colors.whiteColor,
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  getAssetImage(R.images.logo,
                      height: FetchPixels.getPixelHeight(60),
                      width: FetchPixels.getPixelWidth(200)),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  Text(
                    "Change Password?",
                    style: R.textStyle.mediumPoppins().copyWith(
                          fontSize: 16,
                          // color: R.colors.whiteColor,
                        ),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(5)),
                  Text(
                    "Password Must Consist of at Least 6 Characters",
                    maxLines: 2,
                    style: R.textStyle.regularPoppins().copyWith(
                          fontSize: 13,
                          // color: R.colors.lightcolor,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(40)),
                  Align(alignment: Alignment.centerLeft,
                    child: Text(
                      "Old Password",
                      style: R.textStyle.regularPoppins().copyWith(
                            fontSize: 13,
                          ),
                    ),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  TextFormField(
                      style: TextStyle(
                        color: R.colors.theme,
                      ),
                      obscureText: oldPassVisible,
                      controller: oldPasswordController,
                      focusNode: oldPassFN,
                      onTap: () {
                        setState(() {});
                      },
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.next,
                      validator: (value) =>
                          FieldValidator.validatePassword(value!),
                      decoration: R.decorations.textFormFieldDecoration(
                          InkWell(
                            onTap: () {
                              oldPassVisible = !oldPassVisible;
                              setState(() {});
                            },
                            child: Icon(
                                !oldPassVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: oldPassFN.hasFocus
                                    ? R.colors.theme
                                    : R.colors.hintText),
                          ),
                          'Enter Old Password')),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  Align(alignment: Alignment.centerLeft,
                    child: Text(
                      "New Password",
                      style: R.textStyle.regularPoppins().copyWith(
                            fontSize: 13,
                          ),
                    ),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  TextFormField(
                      style: TextStyle(
                        color: R.colors.theme,
                      ),
                      obscureText: newPassVisible,
                      controller: newPasswordController,
                      focusNode: newPassFN,
                      onTap: () {
                        setState(() {});
                      },
                      keyboardType: TextInputType.visiblePassword,
                      textInputAction: TextInputAction.next,
                      validator: (value) =>
                          FieldValidator.validatePassword(value!),
                      decoration: R.decorations.textFormFieldDecoration(
                          InkWell(
                            onTap: () {
                              newPassVisible = !newPassVisible;
                              setState(() {});
                            },
                            child: Icon(
                                !newPassVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: newPassFN.hasFocus
                                    ? R.colors.theme
                                    : R.colors.hintText),
                          ),
                          'Enter Password')),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  TextFormField(
                      style: TextStyle(
                        color: R.colors.theme,
                      ),
                      obscureText: confirmPassVisible,
                      controller: confirmPasswordController,
                      focusNode: conFirmPassFN,
                      onTap: () {
                        setState(() {});
                      },
                      validator: (value) =>
                          FieldValidator.validatePasswordMatch(value!,newPasswordController.text),
                      decoration: R.decorations.textFormFieldDecoration(
                          InkWell(
                              onTap: () {
                                confirmPassVisible = !confirmPassVisible;
                                setState(() {});
                              },
                              child: Icon(
                                !confirmPassVisible
                                    ? Icons.visibility_off
                                    : Icons.visibility,
                                color: conFirmPassFN.hasFocus
                                    ? R.colors.theme
                                    : R.colors.hintText,
                              )),
                          'Confirm Password')),
                  getVerSpace(FetchPixels.getPixelHeight(40)),
                  MyButton(
                      onTap: () {
                        if (formKey.currentState!.validate()) {
                       Get.dialog(CongratsDialogue(image: R.images.logo,text: "Your Password is Updated\nPlease Login Again",));
                        }
                      },
                      buttonText: "UPDATE")
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
