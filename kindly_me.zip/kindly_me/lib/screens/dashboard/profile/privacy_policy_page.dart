
import 'package:flutter/material.dart';

import '../../../base/resizer/fetch_pixels.dart';
import '../../../base/widget_utils.dart';
import '../../../resources/resources.dart';
class PrivacyPolicy extends StatelessWidget {
  const PrivacyPolicy({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(      appBar: AppBar(
      centerTitle: true,
      iconTheme: IconThemeData(
        color: R.colors.theme, // <-- SEE HERE
      ),
      backgroundColor: R.colors.whiteColor,
      title: Text("Privacy Policy",style: R.textStyle.mediumPoppins().copyWith(fontSize: 16),),),
    body:  SingleChildScrollView(
      child: getPaddingWidget(
        EdgeInsets.all(FetchPixels.getPixelWidth(20)),
        Container(
          padding:   EdgeInsets.all( FetchPixels.getPixelWidth(20)),
          decoration: BoxDecoration(
              color: R.colors.whiteColor,
              borderRadius: BorderRadius.circular(4)),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [


                Text("Why do we User it?",style: R.textStyle.mediumPoppins().copyWith(fontSize: 16,color: R.colors.theme),),
                Text(R.dummyData.longerText,style: R.textStyle.regularPoppins().copyWith(fontSize: 14,color: R.colors.hintText),),
                getVerSpace( FetchPixels.getPixelHeight(10),),

              ]),
        ),
      ),
    ),
    );
  }
}
