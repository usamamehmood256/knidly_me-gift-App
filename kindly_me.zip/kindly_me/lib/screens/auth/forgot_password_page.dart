import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/base/widget_utils.dart';
import 'package:kindly_me/widgets/my_button.dart';

import '../../dialogs/congrats_dialogue.dart';
import '../../resources/resources.dart';
import '../../utils/validator.dart';

class ForgotPassWordView extends StatelessWidget {
  ForgotPassWordView({Key? key}) : super(key: key);
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController emailCT = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.5,
        backgroundColor: R.colors.whiteColor,
        centerTitle: true,
        title: Text(
          "Forgot Password",
          style: R.textStyle.mediumPoppins().copyWith(fontSize: 15),
        ),
      ),
      body: getPaddingWidget(
        EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(children: [
              getVerSpace(FetchPixels.getPixelHeight(150)),
              getAssetImage(R.images.logo,
                  height: FetchPixels.getPixelHeight(70),
                  width: FetchPixels.getPixelWidth(200)),

              Text("Please Provide Your Registered Email",style: R.textStyle.mediumPoppins().copyWith(fontSize: 15),),
               getVerSpace(FetchPixels.getPixelHeight(20)),
              TextFormField(
                controller: emailCT,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                cursorColor: R.colors.theme,
                keyboardType: TextInputType.emailAddress,
                validator: (value) => FieldValidator.validateEmail(value!),
                decoration: R.decorations.textFormFieldDecoration(null, "email"),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              MyButton(
                  onTap: () {
                    if(formKey.currentState!.validate()){
                      Get.dialog(CongratsDialogue(
                        image: R.images.logo,
                        text:
                        "We Have Sent Reset Password Link to your Registered Email",
                      ));
                    }

                  },
                  buttonText: "Reset Password"),
            ]),
          ),
        ),
      ),
    );
  }
}
