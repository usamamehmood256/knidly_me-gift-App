import 'package:circular_profile_avatar/circular_profile_avatar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/screens/auth/provider/auth_provider.dart';
import 'package:provider/provider.dart';

import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../dialogs/congrats_dialogue.dart';
import '../../resources/resources.dart';
import '../../routes/app_routes.dart';
import '../../utils/validator.dart';
import '../../widgets/my_button.dart';

class SignUpVIew extends StatefulWidget {
  SignUpVIew({Key? key}) : super(key: key);

  @override
  State<SignUpVIew> createState() => _SignUpVIewState();
}

class _SignUpVIewState extends State<SignUpVIew> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController emailCT = TextEditingController();

  TextEditingController userNameCT = TextEditingController();

  TextEditingController passwordCT = TextEditingController();

  TextEditingController confirmPasswordCT = TextEditingController();
  FocusNode passFN = FocusNode();
  FocusNode confirmPassPN = FocusNode();
bool passVisible = false;
bool confirmPassVisible = false;
  @override
  void dispose() {
    // TODO: implement dispose
    userNameCT.dispose();
    passwordCT.dispose();
    confirmPasswordCT.dispose();
    passFN.dispose();
    confirmPassPN.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, child) {
        return Scaffold(
          body: getPaddingWidget(
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(40)),
            SingleChildScrollView(
              child: Form(key: formKey,
                child: Column(children: [
                  getVerSpace(FetchPixels.getPixelHeight(100)),
                  getAssetImage(
                    R.images.logo,
                    height: FetchPixels.getPixelHeight(70),
                    width: FetchPixels.getPixelWidth(200),
                  ),
                  Text(
                    "Sign Up to continue to KindlyMe.",
                    style: R.textStyle.regularPoppins().copyWith(fontSize: 15),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  SizedBox(
                    height: FetchPixels.getPixelHeight(100),
                    width: FetchPixels.getPixelWidth(100),
                    child: Stack(

                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: InkWell(onTap: (){
                            auth.getImage1();
                            auth.update();
                          },
                            child:auth.pickedImage==null? CircularProfileAvatar(
                                "",
                                radius: FetchPixels.getPixelHeight(60),
                                child:
                                getAssetImage(R.images.proImage, boxFit: BoxFit.cover)
                            ):CircularProfileAvatar(
                              "",
                              radius: FetchPixels.getPixelHeight(60),
                              child: Image.file(auth.pickedImage!,fit: BoxFit.cover, ),
                            ),
                          ),
                        ),
                        Align(alignment: Alignment.bottomRight,
                          child: Container(
                            padding: EdgeInsets.all(FetchPixels.getPixelHeight(3)),
                            decoration: BoxDecoration(
                                color: R.colors.theme, shape: BoxShape.circle),
                            child: Icon(Icons.edit,size: FetchPixels.getPixelWidth(20),),
                          ),
                        )
                      ],
                    ),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  TextFormField(
                    controller: emailCT,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    cursorColor: R.colors.theme,
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) => FieldValidator.validateEmail(value!),
                    decoration:
                        R.decorations.textFormFieldDecoration(null, "email "),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  TextFormField(
                    controller: userNameCT,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    cursorColor: R.colors.theme,
                    keyboardType: TextInputType.name,
                    validator: (value) => FieldValidator.validateName(value!),
                    decoration:
                        R.decorations.textFormFieldDecoration(null, "username "),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  TextFormField(
                    controller: passwordCT,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    cursorColor: R.colors.theme,
                    focusNode: passFN,
                    obscureText: passVisible,
                    onTap: () {
                      setState(() {

                      });
                    },
                    keyboardType: TextInputType.visiblePassword,
                    validator: (value) => FieldValidator.validatePassword(value!),
                    decoration: R.decorations
                        .textFormFieldDecoration(GestureDetector(
                        onTap: () {
                          passVisible =! passVisible;
                          setState(() {

                          });

                        },
                        child: Icon(passVisible?Icons.visibility_off:Icons.visibility,color:passFN.hasFocus?R.colors.theme:R.colors.hintText ,)),"enter password "),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  TextFormField(
                    controller: confirmPasswordCT,
                    obscureText: confirmPassVisible,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    cursorColor: R.colors.theme,
                    focusNode: confirmPassPN,
                    onTap: () {
                      setState(() {

                      });
                    },
                    keyboardType: TextInputType.visiblePassword,
                    validator: (value) => FieldValidator.validatePasswordMatch(
                        value!, passwordCT.text),
                    decoration: R.decorations
                        .textFormFieldDecoration(GestureDetector(
                        onTap: () {
                          confirmPassVisible =! confirmPassVisible;
                          setState(() {

                          });

                        },
                        child: Icon(confirmPassVisible?Icons.visibility_off:Icons.visibility,color:confirmPassPN.hasFocus?R.colors.theme:R.colors.hintText ,)),"confirm password "),
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  Row(
                    children: [
                      SizedBox(
                        height: FetchPixels.getPixelHeight(20),
                        
                        width: FetchPixels.getPixelWidth(20),
                        child: Checkbox(
                            activeColor: R.colors.theme,
                            checkColor: R.colors.whiteColor,
                            //only check box
                            value: auth.checkValue, //unchecked
                            onChanged: (bool? value) {
                              //value returned when checkbox is clicked

                              auth.checkValue = value!;
                              auth.update();
                            }),
                      ),
                      getHorSpace(FetchPixels.getPixelWidth(10)),
                      Text(
                        "I agree with the terms & policy.",
                        style: R.textStyle
                            .regularPoppins()
                            .copyWith(color: R.colors.hintText),
                      )
                    ],
                  ),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  MyButton(onTap: () {
                    if(formKey.currentState!.validate()){
                      Get.dialog(CongratsDialogue(text: "We Have Sent a Verification link on YOur Provided Email\nPlease Verify Your Email and Login",image: R.images.logo,));

                    }

                  }, buttonText: "Sign Up"),
                  getVerSpace(FetchPixels.getPixelHeight(10)),
                  getVerSpace(FetchPixels.getPixelHeight(20)),
                  getVerSpace(FetchPixels.getPixelHeight(40)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        "Already have an account?",
                        style:
                            R.textStyle.regularPoppins().copyWith(fontSize: 15),
                      ),
                      InkWell(
                          onTap: () {
                            Get.toNamed(Routes.loginView);
                          },
                          child: Text(
                            "Login",
                            style: R.textStyle.regularPoppins().copyWith(
                                fontSize: 15,
                                decoration: TextDecoration.underline),
                          )),
                    ],
                  ),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }
}
