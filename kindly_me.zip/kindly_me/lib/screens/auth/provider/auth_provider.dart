import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';

class AuthProvider extends ChangeNotifier{
  update(){
    notifyListeners();
  }

  /// SignUp Page CheckBox///
  bool checkValue = false;




  ImagePicker imgPicker = ImagePicker();
  File? pickedImage;
  var height, width;
  final picker = ImagePicker();

  Future getImage1() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      pickedImage = File(pickedFile.path);
    } else {
      // ShowMessage.toast("Nothing selected");
    }
    notifyListeners();
  }

}