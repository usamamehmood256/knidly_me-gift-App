import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:kindly_me/utils/validator.dart';
import 'package:kindly_me/widgets/my_button.dart';

import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../resources/resources.dart';
import '../../routes/app_routes.dart';

class LoginView extends StatefulWidget {
  LoginView({Key? key}) : super(key: key);

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController emailCT = TextEditingController();

  TextEditingController passwordCT = TextEditingController();

  bool passVisible = false;

  FocusNode passFN = FocusNode();
  @override
  void dispose() {
    // TODO: implement dispose
    passFN.dispose();
    emailCT.dispose();
    passwordCT.dispose();

    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: getPaddingWidget(
        EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(children: [
              getVerSpace(FetchPixels.getPixelHeight(100)),
              getAssetImage(
                R.images.logo,
                height: FetchPixels.getPixelHeight(70),
                width: FetchPixels.getPixelWidth(200),
              ),
              Text(
                "Log in to continue to KindlyMe.",
                style: R.textStyle.regularPoppins().copyWith(fontSize: 15),
              ),
              getVerSpace(FetchPixels.getPixelHeight(50)),
              TextFormField(
                controller: emailCT,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                cursorColor: R.colors.theme,
                keyboardType: TextInputType.emailAddress,
                validator: (value) => FieldValidator.validateEmail(value!),
                decoration:
                    R.decorations.textFormFieldDecoration(null, "username "),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              TextFormField(
                obscureText: passVisible,
                controller: passwordCT,
                focusNode: passFN,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                cursorColor: R.colors.theme,
                onTap: () {
                  setState(() {});
                },
                keyboardType: TextInputType.visiblePassword,
                validator: (value) => FieldValidator.validatePassword(value!),
                decoration: R.decorations.textFormFieldDecoration(
                    GestureDetector(
                        onTap: () {
                          passVisible = !passVisible;
                          setState(() {});
                        },
                        child: Icon(
                          passVisible ? Icons.visibility_off : Icons.visibility,
                          color: passFN.hasFocus
                              ? R.colors.theme
                              : R.colors.hintText,
                        )),
                    "enter password "),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              MyButton(
                  onTap: () {
                    if (formKey.currentState!.validate()) {
                      Get.offAllNamed(Routes.dashboardView);
                    }
                  },
                  buttonText: "Log In"),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Align(
                  alignment: Alignment.centerRight,
                  child: InkWell(
                    onTap: () {
                      Get.toNamed(Routes.forgotPassWordView);
                    },
                    child: Text(
                      "Forgot Password?",
                      style: R.textStyle.regularPoppins().copyWith(
                          fontSize: 15, decoration: TextDecoration.underline),
                    ),
                  )),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              Text(
                "OR",
                style: R.textStyle.regularPoppins().copyWith(
                      fontSize: 13,
                    ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Text(
                "Login with",
                style: R.textStyle.mediumPoppins().copyWith(
                      fontSize: 15,
                    ),
              ),
              getVerSpace(FetchPixels.getPixelHeight(20)),
              Container(
                height: FetchPixels.getPixelHeight(50),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    color: R.colors.theme,
                    borderRadius: BorderRadius.circular(4)),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      getAssetImage(R.images.facebook,
                          height: FetchPixels.getPixelHeight(25),
                          width: FetchPixels.getPixelWidth(25)),
                      getHorSpace(FetchPixels.getPixelWidth(10)),
                      Text(
                        "Login with Facebook",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(color: R.colors.whiteColor, fontSize: 12),
                      )
                    ]),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Container(
                height: FetchPixels.getPixelHeight(50),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    color: R.colors.twitterColor,
                    borderRadius: BorderRadius.circular(4)),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      getAssetImage(R.images.twitter,
                          height: FetchPixels.getPixelHeight(25),
                          width: FetchPixels.getPixelWidth(25)),
                      getHorSpace(FetchPixels.getPixelWidth(10)),
                      Text(
                        "Login with Twitter",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(color: R.colors.whiteColor, fontSize: 12),
                      )
                    ]),
              ),
              getVerSpace(FetchPixels.getPixelHeight(10)),
              Container(
                height: FetchPixels.getPixelHeight(50),
                width: FetchPixels.width,
                decoration: BoxDecoration(
                    color: R.colors.googleColor,
                    borderRadius: BorderRadius.circular(4)),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      getAssetImage(R.images.google,
                          height: FetchPixels.getPixelHeight(25),
                          width: FetchPixels.getPixelWidth(25)),
                      getHorSpace(FetchPixels.getPixelWidth(10)),
                      Text(
                        "Login with Google",
                        style: R.textStyle
                            .mediumPoppins()
                            .copyWith(color: R.colors.whiteColor, fontSize: 12),
                      )
                    ]),
              ),
              getVerSpace(FetchPixels.getPixelHeight(40)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    "Didn't have an account?",
                    style: R.textStyle.regularPoppins().copyWith(fontSize: 15),
                  ),
                  InkWell(
                      onTap: () {
                        Get.toNamed(Routes.signUpVIew);
                      },
                      child: Text(
                        "Register Now",
                        style: R.textStyle.regularPoppins().copyWith(
                            fontSize: 15, decoration: TextDecoration.underline),
                      )),
                ],
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
