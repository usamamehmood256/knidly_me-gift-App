import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';


import '../../base/resizer/fetch_pixels.dart';
import '../../base/widget_utils.dart';
import '../../resources/resources.dart';
import '../../routes/app_routes.dart';

class SplashView extends StatefulWidget {
  const SplashView({Key? key}) : super(key: key);

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 2), () {
      setState(() {
         Get.offAllNamed(Routes.loginView);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    FetchPixels(context);
    return Scaffold(

        body:  Center(
          child: getAssetImage(R.images.logo,
            height: FetchPixels.getPixelHeight(100), width: FetchPixels.getPixelWidth(200),),
        ),
    );
  }
}
