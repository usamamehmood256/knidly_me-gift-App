import 'package:get/get_navigation/src/routes/get_route.dart';
import 'package:kindly_me/screens/auth/login_Page.dart';
import 'package:kindly_me/screens/dashboard/dashboard_page.dart';



import '../screens/auth/forgot_password_page.dart';
import '../screens/auth/sign_up_page.dart';
import '../screens/dashboard/profile/changepasscurrentpassword.dart';
import '../screens/dashboard/profile/contact_us_page.dart';
import '../screens/dashboard/profile/edit_profile_page.dart';
import '../screens/dashboard/profile/help_page.dart';
import '../screens/dashboard/profile/kindlyme_works_page.dart';
import '../screens/dashboard/profile/main_settings_page.dart';
import '../screens/dashboard/profile/privacy_policy_page.dart';
import '../screens/dashboard/profile/terms_conditions_page.dart';
import '../screens/splash/splash_page.dart';
import 'app_routes.dart';

abstract class AppPages {
  static List<GetPage> pages = [
     GetPage(name: Routes.splash, page: () => const SplashView()),
     GetPage(name: Routes.loginView, page: () =>  LoginView()),
     GetPage(name: Routes.signUpVIew, page: () =>  SignUpVIew()),
     GetPage(name: Routes.forgotPassWordView, page: () =>  ForgotPassWordView()),
     GetPage(name: Routes.dashboardView, page: () =>  const DashboardView(index: 0,)),
     GetPage(name: Routes.editProfileView, page: () =>   EditProfileView()),
     GetPage(name: Routes.mainSettingsView, page: () =>  const MainSettingsView()),
     GetPage(name: Routes.kindlyMeWorksView, page: () =>  const KindlyMeWorksView()),
     GetPage(name: Routes.contactUsView, page: () =>   ContactUsView()),
     GetPage(name: Routes.termsConditionView, page: () =>   TermsConditionView()),
     GetPage(name: Routes.privacyPolicy, page: () =>   PrivacyPolicy()),
     GetPage(name: Routes.faqsView, page: () =>   FaqsView()),
     GetPage(name: Routes.changeCurrentPass, page: () =>   ChangeCurrentPass()),


  ];
}
