class Routes{


static const splash="/";
  static const loginView="/loginView";
  static const signUpVIew="/signUpVIew";
  static const forgotPassWordView="/forgotPassWordView";
  static const dashboardView="/dashboardView";
  static const editProfileView="/editProfileView";
  static const mainSettingsView="/mainSettingsView";
  static const kindlyMeWorksView="/kindlyMeWorksView";
  static const contactUsView="/contactUsView";
  static const termsConditionView="/termsConditionView";
  static const privacyPolicy="/privacyPolicy";
  static const faqsView="/faqsView";
  static const changeCurrentPass="/changeCurrentPass";










}