class AppImages {
  String logo = "logo.png";
  String facebook = "facebook.png";
  String google = "google.png";
  String choose = "choose.png";
  String amount = "amount.png";
  String gift = "gift.png";
  String profile = "profile.png";
  String settings = "settings.png";
  String heart = "heart.png";
  String privacy = "privacy.png";
  String terms = "terms.png";
  String contact = "contact.png";
  String help = "help.png";
  String proImage = "proImage.png";
  String logout = "logout.png";
  String lock = "lock.png";
  String textImage = "textImage.png";
  String giftImage = "giftImage.png";
  String emailImage = "emailImage.png";
  String home = "home.png";
  String selectedHome = "selectedHome.png";
  String selectedGift = "selectedGift.png";
  String dashProfile = "dashProfile.png";
  String selectedProfile = "selectedProfile.png";
  String noti = "noti.png";
  String selectedNoti = "selectedNoti.png";
  String logoutImage = "logoutImage.png";
  String twitter = "twitter.png";
  String dashGift = "dashGift.png";



}
