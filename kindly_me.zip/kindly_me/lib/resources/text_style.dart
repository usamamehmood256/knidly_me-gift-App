import 'package:flutter/cupertino.dart';

import '../resources/resources.dart';

class AppTextStyle {
  ///textstyles///

  TextStyle regularPoppins() {
    return TextStyle(
      fontSize: 12,
      fontFamily: 'Poppins',
      letterSpacing: 0.05,
      color: R.colors.blackColor,
      fontWeight: FontWeight.w400,
    );
  }
  TextStyle mediumPoppins() {
    return TextStyle(
      fontSize: 15,
      fontFamily: 'Poppins',
      letterSpacing: 0,
      color: R.colors.blackColor,
      fontWeight: FontWeight.w500,
    );
  }

}
