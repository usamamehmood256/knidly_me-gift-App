import 'package:flutter/material.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';
import 'package:kindly_me/resources/resources.dart';

class AppDecorations {
  InputDecoration textFormFieldDecoration(
    Widget? suffix,
    String hintText,
  ) {
    return InputDecoration(
      contentPadding: EdgeInsets.all(FetchPixels.getPixelHeight(15)),
      suffixIcon: suffix,
      isDense: true,
      labelStyle: R.textStyle.regularPoppins(),
      floatingLabelBehavior: FloatingLabelBehavior.never,
      focusedBorder: OutlineInputBorder(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        borderSide: BorderSide(
          width: 1,
          color: R.colors.theme,
        ),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        borderSide: BorderSide(width: 1, color: R.colors.borderColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: const BorderRadius.all(Radius.circular(4)),
        borderSide: BorderSide(width: 1, color: R.colors.borderColor),
      ),
      border: OutlineInputBorder(
          borderSide: BorderSide(width: 1, color: R.colors.borderColor),
          borderRadius: const BorderRadius.all(Radius.circular(4))),
      // filled: true,
      // fillColor: R.colors.blackColor.withOpacity(0.36),
      focusColor: R.colors.theme,
      hintText: hintText,

      hintStyle: R.textStyle
          .regularPoppins()
          .copyWith(fontSize: 13, color: R.colors.hintText),


      //  border: OutlineInputBorder()
    );
  }


}
