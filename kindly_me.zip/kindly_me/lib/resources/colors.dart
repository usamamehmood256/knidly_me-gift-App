import 'package:flutter/material.dart';

class AppColors {
  Color whiteColor = Colors.white;
  Color blackColor = Colors.black;
  Color fillColor = Colors.black.withOpacity(0.4);
  Color transparent = Colors.transparent;
  Color theme = const Color(0xFF3366FF);
  Color borderColor = const Color(0xFF8C8C8C);
  Color hintText = const Color(0xFF929292);
  Color bgColor = const Color(0xFFE2E8FE);
  Color gradient = const Color(0xFF65CAFF);
  Color profileFill = const Color(0xFFF5F5F5);
  Color twitterColor = const Color(0xFF33B6FF);
  Color googleColor = const Color(0xFFED1313);









}
