import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:kindly_me/routes/app_pages.dart';
import 'package:kindly_me/routes/app_routes.dart';
import 'package:kindly_me/screens/auth/provider/auth_provider.dart';
import 'package:kindly_me/widgets/app_theme.dart';
import 'package:provider/provider.dart';
import 'package:responsive_framework/responsive_wrapper.dart';
import 'package:responsive_framework/utils/scroll_behavior.dart';


void main() {
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(create: (_) => AuthProvider()),


  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(

      // home: ,
      debugShowCheckedModeBanner: false,
      darkTheme: ThemeData.dark(),
      getPages: AppPages.pages,
      initialRoute: Routes.splash,
      title: "Kindly Me",
      theme: myTheme,
      // ThemeData(
      //   // * Create your own palette, because black is not a material color.
      //   primarySwatch: const MaterialColor(
      //     0xFF03A9F4,
      //     <int, Color>{
      //       50: Color(0xff288E68),
      //       100: Color(0xff288E68),
      //       200: Color(0xff288E68),
      //       300: Color(0xff288E68),
      //       400: Color(0xff288E68),
      //       500: Color(0xff288E68),
      //       600: Color(0xff288E68),
      //       700: Color(0xff288E68),
      //       800: Color(0xff288E68),
      //       900: Color(0xff288E68),
      //     },
      //   ),
      //   scaffoldBackgroundColor: R.colors.whiteColor,
      // ),
      builder: (context, widget) {
        return ResponsiveWrapper.builder(
          BouncingScrollWrapper.builder(context, widget!),
          maxWidth: 1200,
          minWidth: 320,
          defaultName: MOBILE,
          defaultScale: true,
          breakpoints: [
            const ResponsiveBreakpoint.resize(320,
                name: MOBILE, scaleFactor: 1.0),
            const ResponsiveBreakpoint.resize(480, name: MOBILE),
            const ResponsiveBreakpoint.resize(600, name: MOBILE),
            const ResponsiveBreakpoint.autoScale(850, name: TABLET),
            const ResponsiveBreakpoint.resize(1080, name: DESKTOP),
          ],
        );
      },
    );
  }
}


