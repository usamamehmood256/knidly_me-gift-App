import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';


import '../base/resizer/fetch_pixels.dart';
import '../base/widget_utils.dart';
import '../resources/resources.dart';
import '../routes/app_routes.dart';

class CongratsDialogue1 extends StatefulWidget {
  final String text;
  final String image;

  const CongratsDialogue1({Key? key,required this.text,required this.image}) : super(key: key);

  @override
  State<CongratsDialogue1> createState() => _CongratsDialogue1State();
}

class _CongratsDialogue1State extends State<CongratsDialogue1>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> scaleAnimation;
  Timer? timer;
  @override
  void initState() {
    timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      timer.cancel();
       Get.offAllNamed(Routes.dashboardView);
    }
    );
    super.initState();

    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    scaleAnimation =
        CurvedAnimation(parent: controller, curve: Curves.easeInOut);

    controller.addListener(() {
      setState(() {});
    });

    controller.forward();
  }

  var horSpace = FetchPixels.getPixelHeight(20);

  @override
  Widget build(BuildContext context) {
    FetchPixels(context);
    return ScaleTransition(
      scale: scaleAnimation,
      child: Dialog(
        backgroundColor: R.colors.whiteColor,
        insetPadding:
            EdgeInsets.symmetric(horizontal: FetchPixels.getPixelWidth(20)),
        shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(FetchPixels.getPixelHeight(22))),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.min,
          children: [
            getVerSpace(FetchPixels.getPixelHeight(30)),
            getAssetImage(widget.image,
            height: FetchPixels.getPixelHeight(70),
              width: FetchPixels.getPixelWidth(120)
            ),
            // getSvgImage("delete.svg"),
            Text("CONGRATULATIONS",style: R.textStyle.mediumPoppins().copyWith(color: R.colors.theme),),
            getVerSpace(FetchPixels.getPixelHeight(20)),
            getPaddingWidget(
              EdgeInsets.symmetric(horizontal: FetchPixels.getPixelHeight(64)),
              getMultilineCustomFont(
                  widget.text,
                  16,
                  Colors.black,
                  fontWeight: FontWeight.w400,
                  txtHeight: FetchPixels.getPixelHeight(1.5),
                  textAlign: TextAlign.center),
            ),

            getVerSpace(FetchPixels.getPixelHeight(30)),
          ],
        ),
      ),
    );
  }
}
