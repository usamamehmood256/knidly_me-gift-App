import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kindly_me/base/resizer/fetch_pixels.dart';

import '../resources/resources.dart';

class DropDownDynamicWidget extends StatefulWidget {
  final ExpandableController controller;
  final List<String> dropDownItems;
  final String heading;
  final Function() onTap;
  final ValueSetter<String> onSelect;
  final String selectedWord;

  const  DropDownDynamicWidget(
      {super.key,
      required this.controller,
      required this.dropDownItems,
      required this.heading,
      required this.onTap,
      required this.selectedWord,
      required this.onSelect});

  @override
  _DropDownDynamicWidgetState createState() => _DropDownDynamicWidgetState(
      controller: controller,
      dropDownItems: dropDownItems,
      heading: heading,
      onTap: onTap,
      selectedWord: selectedWord);
}

class _DropDownDynamicWidgetState extends State<DropDownDynamicWidget> {
  ExpandableController controller;
  List<String> dropDownItems;
  String heading;
  Function()? onTap;
  String selectedWord;
  _DropDownDynamicWidgetState(
      {required this.controller,
      required this.dropDownItems,
      required this.heading,
      required this.onTap,
      required this.selectedWord});

  @override
  Widget build(BuildContext context) {
    return ExpandableNotifier(
        controller: controller,
        child: Column(children: [
          Expandable(
            collapsed: ExpandableButton(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: FetchPixels.getPixelHeight(60),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                          color: R.colors.hintText.withOpacity(0.2),
                          blurRadius: 2)
                    ],
                    borderRadius: BorderRadius.circular(4),
                    color: R.colors.whiteColor,
                  ),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          selectedWord.isEmpty ? "" : selectedWord,
                          style: R.textStyle.mediumPoppins().copyWith(
                              color: selectedWord.isEmpty
                                  ? R.colors.blackColor
                                  : R.colors.blackColor,
                              fontSize: 12),
                        ),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 18,
                          color: R.colors.blackColor,
                        ),
                      ]),
                ),
              ),
            ),
            expanded: Column(
              children: [
                GestureDetector(
                  onTap: onTap,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      height:FetchPixels.getPixelHeight(60),
                       width: FetchPixels.width,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                              color: R.colors.hintText.withOpacity(0.3),
                              blurRadius: 2)
                        ],
                        borderRadius: BorderRadius.circular(4),
                        color: R.colors.whiteColor,
                      ),
                      padding:
                          const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              selectedWord.isEmpty ? "" : selectedWord,
                              style: R.textStyle
                                  .regularPoppins()
                                  .copyWith(fontSize: 12),
                            ),
                            const Icon(
                              Icons.keyboard_arrow_up,
                              color: Colors.black,
                            )
                          ]),
                    ),
                  ),
                ),
                Container(
                  width: FetchPixels.width,
                  decoration: BoxDecoration(
                      color: R.colors.whiteColor,
                      borderRadius: BorderRadius.circular(4)),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: List.generate(dropDownItems.length, (index) {
                      return Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              color: Colors.white,
                              child: Text(
                                dropDownItems[index],
                                style: R.textStyle
                                    .regularPoppins()
                                    .copyWith(
                                        fontSize: 12,
                                        color: R.colors.hintText),
                                textAlign: TextAlign.left,
                              ),
                            ),
                          ),
                        ],
                      );
                    }),
                  ),
                ),
              ],
            ),
          ),
        ]));
  }
}
