import 'package:flutter/material.dart';



MaterialColor primaryMaterialColor = const MaterialColor(
  0xFF000000,
  <int, Color>{
    50: Colors.black,
    100:Colors.black,
    200: Colors.black,
    300: Colors.black,
    400: Colors.black,
    500:Colors.black,
    600: Colors.black,
    700:Colors.black,
    800: Colors.black,
    900: Colors.black,
  },
);




ThemeData myTheme = ThemeData(
  fontFamily: "customFont",
  primaryColorLight: const Color(0xfff6cb13),
  primaryColor: const Color(0xfff6cb13),
  primarySwatch: primaryMaterialColor,
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xfff6cb13),
    ),
  ),
);
