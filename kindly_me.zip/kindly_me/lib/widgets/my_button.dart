import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../resources/resources.dart';

class MyButton extends StatefulWidget {
  final Function onTap;
  final String buttonText;
  final bool isPrefixIcon;
  final Color? color;
  final Color? textColor;

   MyButton({
    required this.onTap,
    required this.buttonText,
    this.textColor,
    this.isPrefixIcon = false,
    this.color,
  });
  @override
  _MyButtonState createState() => _MyButtonState();
}

class _MyButtonState extends State<MyButton> {
  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4),
      side: BorderSide(color:R.colors.whiteColor,width: 0.1)
      ),
      
      elevation: 0,
      minWidth: Get.width * 0.3,
      height: Get.height * .06,
      color: widget.color ?? R.colors.theme,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(widget.buttonText,
              style: R.textStyle.mediumPoppins().copyWith(
                    color: widget.textColor ?? R.colors.whiteColor,
                    fontSize: 15
                  )),
        ],
      ),
      onPressed: () {
        widget.onTap();
      },
    );
  }
}
